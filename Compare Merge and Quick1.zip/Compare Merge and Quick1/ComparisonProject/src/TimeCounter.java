import java.util.Arrays;
import java.util.Random;

public class TimeCounter {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        int size = 10;
        
    	for(int k = 0 ; k < 5 ; k++ ){
        	size = size *10 ;
        	int n = size + 1;
        	int maximum = 100000;
            int[] array = new int[n];

            for (int i = 0; i < array.length - 1; i++) {
                array[i] = new Random().nextInt(maximum);
            	//array[i]=array.length-i;
            }

            // The last number of the quick sort is the biggest
            array[size - 1] = maximum + 1;

            long QuickStart = System.currentTimeMillis();
            QuickSort quicksort=new QuickSort(array);
            long QuickEnd = System.currentTimeMillis();

            long MergeStart = System.currentTimeMillis();
            MergeSort mergesort=new MergeSort(array);
            long MergeEnd = System.currentTimeMillis();

 //          System.out.println(Arrays.toString(array));
  //         System.out.println(Arrays.toString(quicksort.arrayA));
  //         System.out.println(Arrays.toString(mergesort.nums));
            System.out.println("size:" + size);
            System.out.println("quick sort: " + (QuickEnd - QuickStart));
            System.out.println("merge sort: " + (MergeEnd - MergeStart));
        }
       
    /*    int size = 999;
        int n = size + 1;
    	//int maximum = 99999;
        int[] array = new int[n];

        for (int i = 0; i < n - 1; i++) {
            //array[i] = new Random().nextInt(maximum);
        	array[i]=n-i;
        
        }

        // The last number of the quick sort is the biggest
        //array[size - 1] = maximum + 1;

//        long QuickStart = System.currentTimeMillis();
//        new QuickSort(array);
//        long QuickEnd = System.currentTimeMillis();

        long MergeStart = System.currentTimeMillis();
        MergeSort mergesort=new MergeSort(array);
        long MergeEnd = System.currentTimeMillis();

      System.out.println(Arrays.toString(array));
       System.out.println(Arrays.toString(mergesort.arrayA));
        System.out.println("size:" + size);
//        System.out.println("quick sort: " + (QuickEnd - QuickStart));
        System.out.println("merge sort: " + (MergeEnd - MergeStart));
    */

    }
}