public class QuickSort {

    public int[] arrayA;

    public QuickSort(int[] array) {
        this.arrayA = array.clone();   // copy array to arrayA
        sort(0, array.length - 2);
    }

    public void sort(int p, int q) {
        if (p < q) {
            int j = partition(p, q);
            sort(p, j - 1);
            sort(j + 1, q);
        }
    }

    public int partition(int p, int q) {
        int j = q;
        int axis = arrayA[p];
        int i = p;

        while (true) {

            // Find the first number which bigger than axis from left to right
            while (arrayA[i] <= axis) {
                i++;
            };

            // Find the first number which smaller and equal to axis from right to left
            while (arrayA[j] > axis) {
                j--;
            };

            if (i < j) {
                swap(i, j);
            } else {
                break;
            }
        }

        arrayA[p] = arrayA[j];
        arrayA[j] = axis;

        return j;
    }

    public void swap(int i, int j) {
        int tmp = arrayA[i];
        arrayA[i] = arrayA[j];
        arrayA[j] = tmp;
    }

}